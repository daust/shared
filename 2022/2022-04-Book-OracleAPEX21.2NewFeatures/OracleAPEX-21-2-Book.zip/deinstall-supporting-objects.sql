alter table oehr_customers drop column tags;
alter table oehr_customers drop column geometry;

drop view oehr_customers_rl_v;

prompt  ...done
