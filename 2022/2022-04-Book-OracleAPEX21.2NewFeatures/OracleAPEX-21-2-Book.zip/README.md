This is additional material for the book "Oracle Application Express 21.2 - Explore the new Features" (by Dietmar Aust).

You can find more information here: [https://dietmaraust.com/books/apex-new-features-21-2](https://dietmaraust.com/books/apex-new-features-21-2). 

